#ifndef _RELAYS_H
#define _RELAYS_H
#include "stm32f10x.h"
#include "system.h"


#define GPIO_RELAYS_PIN  GPIO_Pin_11
#define GPIO_RELAYS_PORT GPIOA
#define RCC_APBx_RELAYS_CMD   RCC_APB2PeriphClockCmd
#define RCC_APBx_RELAYS_CLK   RCC_APB2Periph_GPIOA

#define relays PAout(11)

#define RELAYS_ON  (relays=1)
#define RELAYS_OFF (relays=0)

void RELAYS_Init(void);
#endif

