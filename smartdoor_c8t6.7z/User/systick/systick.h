#ifndef _SYSTICK_H
#define _SYSTICK_H
#include "stm32f10x.h"

void tim4_init(uint16_t prescaler);
void tim4_delay(uint16_t count);
void delay_us(uint16_t us);
void delay_ms(int ms);

#endif
