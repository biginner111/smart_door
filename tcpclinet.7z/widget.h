#ifndef WIDGET_H
#define WIDGET_H

#include <QWidget>
#include <QDebug>//使用调试
#include <QMessageBox>

#include <QTcpSocket>//tcp客户端
#include <QHostAddress>//使用其函数

QT_BEGIN_NAMESPACE
namespace Ui { class Widget; }
QT_END_NAMESPACE

class Widget : public QWidget
{
    Q_OBJECT

public:
    Widget(QWidget *parent = nullptr);
    ~Widget();

private slots:
    void on_cancel_pushButton_clicked();

    void on_connect_pushButton_clicked();

    void on_send_pushButton_clicked();

    void recv_slots();
private:
    Ui::Widget *ui;
    QTcpSocket *tcpscoket;
};
#endif // WIDGET_H
