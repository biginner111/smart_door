#ifndef _ESP8266_H
#define _ESP8266_H

#include "stm32f10x.h"

/*��������MQTTģʽ��֧�ֲ����ɱ䣬���������ʹ��MQTT*/
#define MQTT_SET  


typedef enum{
 ESP8266_OK,
 ESP8266_ERR,
}ESP8266_STATE;

typedef enum{
 ESP8266_STATION=1,
 ESP8266_SOFTAP,
 ESP8266_SOFTAP_STATION,
}ESP8266_MODE;

typedef enum{
 Single_linnk,
 Multiple_links,
}ESP_CONNECT_MODE;

typedef enum{
ordinary_mode=0,
unvarnished_mode,
}TRANSMIT_MODE;

typedef enum{
SERVER_CLOSE,
SERVER_OPEN,
}SERVER_SWITCH;

//�����������շ��ͻ�����
#define ESP8266_TXBUFF_SIZE               (256)
#define ESP8266_RXBUFF_SIZE               (256)
															            
// ����2-USART2
#define  ESP8266_USARTx                   USART2
#define  ESP8266_USART_CLK                RCC_APB1Periph_USART2
#define  ESP8266_USART_APBxClkCmd         RCC_APB1PeriphClockCmd
#define  ESP8266_USART_BAUDRATE           115200

// USART GPIO ���ź궨��
#define  ESP8266_USART_GPIO_CLK           (RCC_APB2Periph_GPIOA)
#define  ESP8266_USART_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd

#define  ESP8266_USART_RX_GPIO_PORT       GPIOA
#define  ESP8266_USART_TX_GPIO_PORT       GPIOA
#define  ESP8266_USART_RX_GPIO_PIN        GPIO_Pin_3
#define  ESP8266_USART_TX_GPIO_PIN        GPIO_Pin_2

#define  ESP8266_USART_IRQ                USART2_IRQn
#define  ESP8266_USART_IRQHandler         USART2_IRQHandler

//TCP_CLINENT
#define ssid   "One"
#define pwd    "12345678"
#define IPaddr "mqtts.heclouds.com"
#define Port   "1883"

//TCP_SERVER
#define ap_ssid  "one"
#define ap_pwd   "66666666"
#define ap_port  "8080"
#define ap_ecn    "0"


extern uint8_t ESP8266_RxBuff[ESP8266_RXBUFF_SIZE]; 
void ESP8266_CLIENT_INIT(void);
void ESP8266_SERVER_INIT(void);
void ESP8266_SendStr( char* fmt,...);
 //uint8_t*  ESP8266_RECIEVE(void);
 void data_parse(uint8_t* data_to_parse,uint8_t *parse_complete_data);
#endif
