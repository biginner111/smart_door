#include "widget.h"
#include "ui_widget.h"

Widget::Widget(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::Widget)
{
    ui->setupUi(this);
    this->setWindowTitle("TCP客户端");
    tcpscoket=new QTcpSocket;


    //设置背景图片
    QString path(":/src/src/background.png");
    QPixmap pix(path);
    ui->back_label->setPixmap(pix);
    //位于底层
    ui->back_label->lower();

    connect(tcpscoket,&QTcpSocket::readyRead,this,&Widget::recv_slots);
}

Widget::~Widget()
{
    delete ui;
}


void Widget::on_cancel_pushButton_clicked()
{
    this->close();
}

void Widget::on_connect_pushButton_clicked()
{
   //获取输入内容
    QString IP=ui->ip_lineEdit->text();
    QString PORT=ui->port_lineEdit->text();
   //连接服务器
   tcpscoket->connectToHost(QHostAddress(IP),PORT.toUShort());

   //连接客户端成功，socket发出信号
   connect(tcpscoket,&QTcpSocket::connected,[this](){
      QMessageBox::information(this,"连接情况","成功");
   });
   //客户端断开连接，socket发出一个信号
   connect(tcpscoket,&QTcpSocket::disconnected,[this](){
      QMessageBox::warning(this,"连接情况","断开连接");
   });

}

void Widget::on_send_pushButton_clicked()
{
  QString str=ui->send_lineEdit->text();
  tcpscoket->write(str.toUtf8());
}

void Widget::recv_slots(){
    QByteArray recv_buff=tcpscoket->readAll();
    ui->send_lineEdit->setText(QString(recv_buff));
}
