#include "bsp_keyboard.h"
#include "systick.h"
#include "FreeRTOS.h"
#include "task.h"

//��ʼ��
void keyboard_Config(void)
{
    GPIO_InitTypeDef  GPIOA_InitStruct;
    GPIO_InitTypeDef  GPIOB_InitStruct;
    
    // 1����ʱ��
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA |  RCC_APB2Periph_GPIOB| RCC_APB2Periph_AFIO , ENABLE);
    GPIO_PinRemapConfig(GPIO_Remap_SWJ_JTAGDisable, ENABLE);

    GPIOA_InitStruct.GPIO_Pin = ( GPIO_Pin_0 | GPIO_Pin_1);
    GPIOA_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIOA_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOA, &GPIOA_InitStruct);
    
    GPIOA_InitStruct.GPIO_Pin = (GPIO_Pin_8 | GPIO_Pin_9 );
    GPIOA_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIOA_InitStruct.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOB, &GPIOA_InitStruct);

    GPIOB_InitStruct.GPIO_Pin = (GPIO_Pin_4 | GPIO_Pin_3 | GPIO_Pin_0 | GPIO_Pin_1);
    GPIOB_InitStruct.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIOB_InitStruct.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOB, &GPIOB_InitStruct);

}

//��ȡ��ֵ
uint8_t keyboard_getvalue1(void)
{
    uint8_t ret = 99;
    GPIO_SetBits(GPIOB, GPIO_Pin_3 | GPIO_Pin_0 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_4);
    // �ж��Ƿ��а�������----�ж�PA15�Ƿ�Ϊ0
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        // �ǣ���ʱ30ms��������
       vTaskDelay(pdMS_TO_TICKS(80));

        // �ٴ��ж�PA15�Ƿ�Ϊ0----�ж����ڰ��¹����л����Ѿ�����̧��
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            // �ǣ��ȴ�����̧��
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            // ִ����Ӧ�Ĳ���
            return ret = KEY_C;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        /* '#' */
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_3;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_2;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        /* '*' */
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_1;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4| GPIO_Pin_0 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_3);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_B;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_6;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_5;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_4;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4 | GPIO_Pin_3 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_0);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_A;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_9;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_8;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_7;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4| GPIO_Pin_3 | GPIO_Pin_0);
    GPIO_ResetBits(GPIOB, GPIO_Pin_1);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_D;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_j;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        vTaskDelay(pdMS_TO_TICKS(80));
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_x;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
			vTaskDelay(pdMS_TO_TICKS(80));
			if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_0;
        }
    }

    return ret;
}

//��ȡ��ֵ
uint8_t keyboard_getvalue2(void)
{
    uint8_t ret = 99;
    GPIO_SetBits(GPIOB, GPIO_Pin_3 | GPIO_Pin_0 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_4);
    // �ж��Ƿ��а�������----�ж�PA15�Ƿ�Ϊ0
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        // �ǣ���ʱ30ms��������
       delay_ms(30);
        // �ٴ��ж�PA15�Ƿ�Ϊ0----�ж����ڰ��¹����л����Ѿ�����̧��
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            // �ǣ��ȴ�����̧��
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            // ִ����Ӧ�Ĳ���
            return ret = KEY_C;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        /* '#' */
       delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_3;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_2;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        /* '*' */
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_1;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4| GPIO_Pin_0 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_3);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_B;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_6;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_5;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_4;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4 | GPIO_Pin_3 | GPIO_Pin_1);
    GPIO_ResetBits(GPIOB, GPIO_Pin_0);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_A;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_9;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_8;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_7;
        }
    }
    GPIO_SetBits(GPIOB,GPIO_Pin_4| GPIO_Pin_3 | GPIO_Pin_0);
    GPIO_ResetBits(GPIOB, GPIO_Pin_1);
    if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_8));
            return ret = KEY_D;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_9));
            return ret = KEY_j;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
    {
        delay_ms(30);
        if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_0));
            return ret = KEY_x;
        }
    }
    else if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
    {
			delay_ms(30);
			if (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1))
        {
            while (0 == GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_1));
            return ret = KEY_0;
        }
    }

    return ret;
}



