#ifndef _AS608APP_H
#define _AS6608APP_H

#include "stm32f10x.h"

uint8_t Add_FR(void);
uint8_t press_FR(void);
uint8_t Del_FR(void);


#endif
